﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace FactoryPattern
{
	public partial class Attempt3 : System.Web.UI.Page
	{
		// Attempt 3.  The factory pattern
		protected void Page_Load(object sender, EventArgs e)
		{
			//ProductFactory factory = new BiscuitFactory();
			ProductFactory factory = new ClothingFactory();

			IProduct product = factory.CreateProduct();

			lblTitle.Text = product.Title;
			lblTitle.BackColor = product.BackgroundColour;

			IEnumerable<string> products = product.Products;

			lstProducts.DataSource = products;
			lstProducts.DataBind();

			lstShipping.DataSource = factory.ShippingLocations();
			lstShipping.DataBind();
		}


		public abstract class ProductFactory
		{
			public abstract IProduct CreateProduct();

			public virtual IEnumerable<string> ShippingLocations()
			{
				return new List<string> {
					"England",
					"Australia",
					"Kazakhstan" };
			}
		}

		public class BiscuitFactory : ProductFactory
		{
			public override IProduct CreateProduct()
			{
				return new Biscuits();
			}

			public override IEnumerable<string> ShippingLocations()
			{
				return new List<string> {
					"England",
					"Kazakhstan" };
			}
		}

		public class ClothingFactory : ProductFactory
		{
			public override IProduct CreateProduct()
			{
				return new Clothing();
			}
		}

		public interface IProduct
		{
			string Title { get; }
			Color BackgroundColour { get; }
			IEnumerable<string> Products { get; }
		}

		public class Biscuits : IProduct
		{
			#region IProduct Members

			public string Title
			{
				get { return "Biscuits For Sale"; }
			}

			public Color BackgroundColour
			{
				get { return Color.LightCoral; }
			}

			public IEnumerable<string> Products
			{
				get
				{
					return new List<string>() {
						"Hob Nob",
						"Custard Creams",
						"Chocolate Digestives" };
				}
			}

			#endregion
		}

		public class Clothing : IProduct
		{
			#region IProduct Members

			public string Title
			{
				get { return "Dog Clothes For Sale"; }
			}

			public Color BackgroundColour
			{
				get { return Color.LightGreen; }
			}

			public IEnumerable<string> Products
			{
				get
				{
					return new List<string>() {
						"Branded cap",
						"Paw warmers",
						"Furry pants" };
				}
			}

			#endregion
		}
	}
}
