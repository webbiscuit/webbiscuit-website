﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace FactoryPattern
{
	public partial class Attempt2 : System.Web.UI.Page
	{
		// Attempt 2.  Much better, but not yet perfect
		protected void Page_Load(object sender, EventArgs e)
		{
			//IProduct product = GetProduct("biscuit");
			IProduct product = GetProduct("clothing");

			lblTitle.Text = product.Title;
			lblTitle.BackColor = product.BackgroundColour;

			IEnumerable<string> products = product.Products;

			lstProducts.DataSource = products;
			lstProducts.DataBind();

			IEnumerable<string> shippingLocations = new List<string>() {
				"England",
				"Australia",
				"Kazakhstan" };

			lstShipping.DataSource = shippingLocations;
			lstShipping.DataBind();
		}

		public IProduct GetProduct(string type)
		{
			if (type == "biscuit")
			{
				return new Biscuits();
			}
			else if (type == "clothing")
			{
				return new Clothing();
			}
			else
			{
				// Returning a default
				// or throw exception, or panic
				return new Biscuits();
			}
		}

		public interface IProduct
		{
			string Title { get; }
			Color BackgroundColour { get; }
			IEnumerable<string> Products { get; }
		}

		public class Biscuits : IProduct
		{
			#region IProduct Members

			public string Title
			{
				get { return "Biscuits For Sale"; }
			}

			public Color BackgroundColour
			{
				get { return Color.LightCoral; }
			}

			public IEnumerable<string> Products
			{
				get
				{
					return new List<string>() {
						"Hob Nob",
						"Custard Creams",
						"Chocolate Digestives" };
				}
			}

			#endregion
		}

		public class Clothing : IProduct
		{
			#region IProduct Members

			public string Title
			{
				get { return "Dog Clothes For Sale"; }
			}

			public Color BackgroundColour
			{
				get { return Color.LightGreen; }
			}

			public IEnumerable<string> Products
			{
				get
				{
					return new List<string>() {
						"Branded cap",
						"Paw warmers",
						"Furry pants" };
				}
			}

			#endregion
		}
	}
}
