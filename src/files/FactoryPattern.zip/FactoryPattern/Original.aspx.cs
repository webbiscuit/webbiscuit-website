﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace FactoryPattern
{
	public partial class Original : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			lblTitle.Text = "Biscuits For Sale";
			lblTitle.BackColor = Color.LightCoral;
			

			IEnumerable<string> biscuits = new List<string>() {
				"Hob Nob",
				"Custard Creams",
				"Chocolate Digestives" };

			lstProducts.DataSource = biscuits;
			lstProducts.DataBind();

			IEnumerable<string> shippingLocations = new List<string>() {
				"England",
				"Australia",
				"Kazakhstan" };

			lstShipping.DataSource = shippingLocations;
			lstShipping.DataBind();
		}
	}


}
