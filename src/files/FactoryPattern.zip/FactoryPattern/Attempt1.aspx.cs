﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace FactoryPattern
{
	public partial class Attempt1 : System.Web.UI.Page
	{
		// Attempt 1.  Don't do this!
		protected void Page_Load(object sender, EventArgs e)
		{
			string product = "biscuit";
			//string product = "clothing";

			if (product == "biscuit")
			{
				lblTitle.Text = "Biscuits For Sale";
				lblTitle.BackColor = Color.LightCoral;

				IEnumerable<string> biscuits = new List<string>() {
					"Hob Nob",
					"Custard Creams",
					"Chocolate Digestives" };

				lstProducts.DataSource = biscuits;
			}
			else if (product == "clothing")
			{
				lblTitle.Text = "Dog Clothes For Sale";
				lblTitle.BackColor = Color.LightGreen;

				IEnumerable<string> biscuits = new List<string>() {
					"Branded cap",
					"Paw warmers",
					"Furry pants" };

				lstProducts.DataSource = biscuits;
			}

			lstProducts.DataBind();

			IEnumerable<string> shippingLocations = new List<string>() {
				"England",
				"Australia",
				"Kazakhstan" };

			lstShipping.DataSource = shippingLocations;
			lstShipping.DataBind();
		}
	}


}
